// Import Third-Party Modules
const express = require('express');
const app = express();
const bodyParser = require('body-parser');


// Default configuration
const host = 'localhost';
const port = 5500;


// HTTP Routes
const routes = require('./api/route');


// Middleware
app.use(bodyParser.json());
app.use(routes);
app.use(express.static('./public'));


// Listen to Incoming Connection
app.listen(port, host, () => {
    console.log(`server has been started via http://${host}:${port}`);
    console.log(`Please access the challenge via http://${host}:${port} in your browser`);
});